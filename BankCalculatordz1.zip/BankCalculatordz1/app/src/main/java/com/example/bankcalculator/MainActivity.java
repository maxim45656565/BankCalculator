package com.example.bankcalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView result;
    private TextView months;
    private Button button;
    private EditText etDuration;
    private EditText etPercent;
    private EditText etSum;
    private List<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.tvResult);
        months = findViewById(R.id.tvMonths);
        button = findViewById(R.id.button);
        etDuration = findViewById(R.id.etDuration);
        etPercent = findViewById(R.id.etPercent);
        etSum = findViewById(R.id.etSum);

        button.setOnClickListener(x -> {
            Log.i("app_tag", "Click submit button");

            String strDuration = etDuration.getText().toString();
            String strPercent = etPercent.getText().toString();
            String strSum = etSum.getText().toString();

            months.setText("");
            list = new ArrayList<>();

            if (!strDuration.isEmpty() && !strPercent.isEmpty() && !strSum.isEmpty()) {
                try {
                    int duration = Integer.parseInt(strDuration);
                    int percent = Integer.parseInt(strPercent);
                    double sum = Double.parseDouble(strSum);

                    if (duration <= 0 || percent <= 0 || sum <= 0) {
                        result.setTextColor(Color.parseColor("#FF0000"));
                        result.setText("Неверный формат данных!");
                    } else {
                        double index = sum * (((double) percent / 100) / 12);
                        for (int i=1; i<=duration; i++) {
                            if (i % 13 == 0) {
                                index = sum * (((double) percent / 100) / 12);
                            }
                            sum += index;

                            list.add(i + "-й месяц: " + String.format("%.2f", sum));
                        }

                        result.setTextColor(Color.parseColor("#000000"));
                        String res = "Итоговый доход: " + String.format("%.2f", sum);
                        result.setText(res);

                        for (String ans : list) {
                            months.append(ans + "\n");
                        }
                    }
                } catch (NumberFormatException e) {
                    result.setTextColor(Color.parseColor("#FF0000"));
                    result.setText("Неверный формат данных!");

                }
            } else {
                result.setTextColor(Color.parseColor("#FF0000"));
                result.setText("Все поля должны быть заполнены!");
            }
        });
    }
}